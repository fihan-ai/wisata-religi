export default function Footer() {
  return (
    <footer className="bg-blue-700 text-white text-center py-4">
      <p>© 2025 Wisata Religi Pangkalpinang. All Rights Reserved.</p>
    </footer>
  );
}
