import React, { useEffect, useState } from 'react';
import api from '../api/axios';

export default function PlacesList() {
  const [places, setPlaces] = useState([]);

  useEffect(() => {
    async function fetchPlaces() {
      try {
        const res = await api.get('/places'); // memanggil http://localhost:8000/api/places
        setPlaces(res.data);
      } catch (err) {
        console.error('fetchPlaces error', err);
      }
    }
    fetchPlaces();
  }, []);

  return (
    <div>
      <h2>Places</h2>
      <ul>
        {places.map(p => <li key={p.id}>{p.name}</li>)}
      </ul>
    </div>
  );
}