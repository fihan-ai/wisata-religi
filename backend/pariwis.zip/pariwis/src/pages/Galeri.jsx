export default function Galeri() {
  return (
    <div className="p-10 text-center">
      <h1 className="text-3xl font-bold text-blue-700 mb-4">Galeri</h1>
      <p className="text-gray-600">Kumpulan foto-foto destinasi religi akan tampil di sini.</p>
    </div>
  );
}
