import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DestinasiController::index
 * @see app/Http/Controllers/DestinasiController.php:12
 * @route '/api/destinasi'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/destinasi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DestinasiController::index
 * @see app/Http/Controllers/DestinasiController.php:12
 * @route '/api/destinasi'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DestinasiController::index
 * @see app/Http/Controllers/DestinasiController.php:12
 * @route '/api/destinasi'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DestinasiController::index
 * @see app/Http/Controllers/DestinasiController.php:12
 * @route '/api/destinasi'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DestinasiController::index
 * @see app/Http/Controllers/DestinasiController.php:12
 * @route '/api/destinasi'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DestinasiController::index
 * @see app/Http/Controllers/DestinasiController.php:12
 * @route '/api/destinasi'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DestinasiController::index
 * @see app/Http/Controllers/DestinasiController.php:12
 * @route '/api/destinasi'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DestinasiController::store
 * @see app/Http/Controllers/DestinasiController.php:17
 * @route '/api/destinasi'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/destinasi',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DestinasiController::store
 * @see app/Http/Controllers/DestinasiController.php:17
 * @route '/api/destinasi'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DestinasiController::store
 * @see app/Http/Controllers/DestinasiController.php:17
 * @route '/api/destinasi'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DestinasiController::store
 * @see app/Http/Controllers/DestinasiController.php:17
 * @route '/api/destinasi'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DestinasiController::store
 * @see app/Http/Controllers/DestinasiController.php:17
 * @route '/api/destinasi'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\DestinasiController::show
 * @see app/Http/Controllers/DestinasiController.php:77
 * @route '/api/destinasi/{destinasi}'
 */
export const show = (args: { destinasi: string | number } | [destinasi: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/destinasi/{destinasi}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DestinasiController::show
 * @see app/Http/Controllers/DestinasiController.php:77
 * @route '/api/destinasi/{destinasi}'
 */
show.url = (args: { destinasi: string | number } | [destinasi: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { destinasi: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    destinasi: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        destinasi: args.destinasi,
                }

    return show.definition.url
            .replace('{destinasi}', parsedArgs.destinasi.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DestinasiController::show
 * @see app/Http/Controllers/DestinasiController.php:77
 * @route '/api/destinasi/{destinasi}'
 */
show.get = (args: { destinasi: string | number } | [destinasi: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DestinasiController::show
 * @see app/Http/Controllers/DestinasiController.php:77
 * @route '/api/destinasi/{destinasi}'
 */
show.head = (args: { destinasi: string | number } | [destinasi: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DestinasiController::show
 * @see app/Http/Controllers/DestinasiController.php:77
 * @route '/api/destinasi/{destinasi}'
 */
    const showForm = (args: { destinasi: string | number } | [destinasi: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DestinasiController::show
 * @see app/Http/Controllers/DestinasiController.php:77
 * @route '/api/destinasi/{destinasi}'
 */
        showForm.get = (args: { destinasi: string | number } | [destinasi: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DestinasiController::show
 * @see app/Http/Controllers/DestinasiController.php:77
 * @route '/api/destinasi/{destinasi}'
 */
        showForm.head = (args: { destinasi: string | number } | [destinasi: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\DestinasiController::update
 * @see app/Http/Controllers/DestinasiController.php:83
 * @route '/api/destinasi/{destinasi}'
 */
export const update = (args: { destinasi: string | number } | [destinasi: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/api/destinasi/{destinasi}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\DestinasiController::update
 * @see app/Http/Controllers/DestinasiController.php:83
 * @route '/api/destinasi/{destinasi}'
 */
update.url = (args: { destinasi: string | number } | [destinasi: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { destinasi: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    destinasi: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        destinasi: args.destinasi,
                }

    return update.definition.url
            .replace('{destinasi}', parsedArgs.destinasi.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DestinasiController::update
 * @see app/Http/Controllers/DestinasiController.php:83
 * @route '/api/destinasi/{destinasi}'
 */
update.put = (args: { destinasi: string | number } | [destinasi: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\DestinasiController::update
 * @see app/Http/Controllers/DestinasiController.php:83
 * @route '/api/destinasi/{destinasi}'
 */
update.patch = (args: { destinasi: string | number } | [destinasi: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DestinasiController::update
 * @see app/Http/Controllers/DestinasiController.php:83
 * @route '/api/destinasi/{destinasi}'
 */
    const updateForm = (args: { destinasi: string | number } | [destinasi: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DestinasiController::update
 * @see app/Http/Controllers/DestinasiController.php:83
 * @route '/api/destinasi/{destinasi}'
 */
        updateForm.put = (args: { destinasi: string | number } | [destinasi: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\DestinasiController::update
 * @see app/Http/Controllers/DestinasiController.php:83
 * @route '/api/destinasi/{destinasi}'
 */
        updateForm.patch = (args: { destinasi: string | number } | [destinasi: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\DestinasiController::destroy
 * @see app/Http/Controllers/DestinasiController.php:119
 * @route '/api/destinasi/{destinasi}'
 */
export const destroy = (args: { destinasi: string | number } | [destinasi: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/destinasi/{destinasi}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DestinasiController::destroy
 * @see app/Http/Controllers/DestinasiController.php:119
 * @route '/api/destinasi/{destinasi}'
 */
destroy.url = (args: { destinasi: string | number } | [destinasi: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { destinasi: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    destinasi: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        destinasi: args.destinasi,
                }

    return destroy.definition.url
            .replace('{destinasi}', parsedArgs.destinasi.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DestinasiController::destroy
 * @see app/Http/Controllers/DestinasiController.php:119
 * @route '/api/destinasi/{destinasi}'
 */
destroy.delete = (args: { destinasi: string | number } | [destinasi: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\DestinasiController::destroy
 * @see app/Http/Controllers/DestinasiController.php:119
 * @route '/api/destinasi/{destinasi}'
 */
    const destroyForm = (args: { destinasi: string | number } | [destinasi: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DestinasiController::destroy
 * @see app/Http/Controllers/DestinasiController.php:119
 * @route '/api/destinasi/{destinasi}'
 */
        destroyForm.delete = (args: { destinasi: string | number } | [destinasi: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const DestinasiController = { index, store, show, update, destroy }

export default DestinasiController