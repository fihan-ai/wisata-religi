import Auth from './Auth'
import KategoriController from './KategoriController'
import DestinasiController from './DestinasiController'
import ArtikelController from './ArtikelController'
import ProfileController from './ProfileController'
const Controllers = {
    Auth: Object.assign(Auth, Auth),
KategoriController: Object.assign(KategoriController, KategoriController),
DestinasiController: Object.assign(DestinasiController, DestinasiController),
ArtikelController: Object.assign(ArtikelController, ArtikelController),
ProfileController: Object.assign(ProfileController, ProfileController),
}

export default Controllers