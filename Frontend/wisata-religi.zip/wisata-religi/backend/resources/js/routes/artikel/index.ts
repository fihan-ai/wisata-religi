import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ArtikelController::index
 * @see app/Http/Controllers/ArtikelController.php:10
 * @route '/api/artikel'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/artikel',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ArtikelController::index
 * @see app/Http/Controllers/ArtikelController.php:10
 * @route '/api/artikel'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArtikelController::index
 * @see app/Http/Controllers/ArtikelController.php:10
 * @route '/api/artikel'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ArtikelController::index
 * @see app/Http/Controllers/ArtikelController.php:10
 * @route '/api/artikel'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ArtikelController::index
 * @see app/Http/Controllers/ArtikelController.php:10
 * @route '/api/artikel'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ArtikelController::index
 * @see app/Http/Controllers/ArtikelController.php:10
 * @route '/api/artikel'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ArtikelController::index
 * @see app/Http/Controllers/ArtikelController.php:10
 * @route '/api/artikel'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ArtikelController::store
 * @see app/Http/Controllers/ArtikelController.php:15
 * @route '/api/artikel'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/artikel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ArtikelController::store
 * @see app/Http/Controllers/ArtikelController.php:15
 * @route '/api/artikel'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArtikelController::store
 * @see app/Http/Controllers/ArtikelController.php:15
 * @route '/api/artikel'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ArtikelController::store
 * @see app/Http/Controllers/ArtikelController.php:15
 * @route '/api/artikel'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ArtikelController::store
 * @see app/Http/Controllers/ArtikelController.php:15
 * @route '/api/artikel'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ArtikelController::show
 * @see app/Http/Controllers/ArtikelController.php:37
 * @route '/api/artikel/{artikel}'
 */
export const show = (args: { artikel: string | number } | [artikel: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/artikel/{artikel}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ArtikelController::show
 * @see app/Http/Controllers/ArtikelController.php:37
 * @route '/api/artikel/{artikel}'
 */
show.url = (args: { artikel: string | number } | [artikel: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { artikel: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    artikel: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        artikel: args.artikel,
                }

    return show.definition.url
            .replace('{artikel}', parsedArgs.artikel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArtikelController::show
 * @see app/Http/Controllers/ArtikelController.php:37
 * @route '/api/artikel/{artikel}'
 */
show.get = (args: { artikel: string | number } | [artikel: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ArtikelController::show
 * @see app/Http/Controllers/ArtikelController.php:37
 * @route '/api/artikel/{artikel}'
 */
show.head = (args: { artikel: string | number } | [artikel: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ArtikelController::show
 * @see app/Http/Controllers/ArtikelController.php:37
 * @route '/api/artikel/{artikel}'
 */
    const showForm = (args: { artikel: string | number } | [artikel: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ArtikelController::show
 * @see app/Http/Controllers/ArtikelController.php:37
 * @route '/api/artikel/{artikel}'
 */
        showForm.get = (args: { artikel: string | number } | [artikel: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ArtikelController::show
 * @see app/Http/Controllers/ArtikelController.php:37
 * @route '/api/artikel/{artikel}'
 */
        showForm.head = (args: { artikel: string | number } | [artikel: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ArtikelController::update
 * @see app/Http/Controllers/ArtikelController.php:43
 * @route '/api/artikel/{artikel}'
 */
export const update = (args: { artikel: string | number } | [artikel: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/api/artikel/{artikel}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\ArtikelController::update
 * @see app/Http/Controllers/ArtikelController.php:43
 * @route '/api/artikel/{artikel}'
 */
update.url = (args: { artikel: string | number } | [artikel: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { artikel: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    artikel: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        artikel: args.artikel,
                }

    return update.definition.url
            .replace('{artikel}', parsedArgs.artikel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArtikelController::update
 * @see app/Http/Controllers/ArtikelController.php:43
 * @route '/api/artikel/{artikel}'
 */
update.put = (args: { artikel: string | number } | [artikel: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\ArtikelController::update
 * @see app/Http/Controllers/ArtikelController.php:43
 * @route '/api/artikel/{artikel}'
 */
update.patch = (args: { artikel: string | number } | [artikel: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ArtikelController::update
 * @see app/Http/Controllers/ArtikelController.php:43
 * @route '/api/artikel/{artikel}'
 */
    const updateForm = (args: { artikel: string | number } | [artikel: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ArtikelController::update
 * @see app/Http/Controllers/ArtikelController.php:43
 * @route '/api/artikel/{artikel}'
 */
        updateForm.put = (args: { artikel: string | number } | [artikel: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\ArtikelController::update
 * @see app/Http/Controllers/ArtikelController.php:43
 * @route '/api/artikel/{artikel}'
 */
        updateForm.patch = (args: { artikel: string | number } | [artikel: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ArtikelController::destroy
 * @see app/Http/Controllers/ArtikelController.php:50
 * @route '/api/artikel/{artikel}'
 */
export const destroy = (args: { artikel: string | number } | [artikel: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/artikel/{artikel}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ArtikelController::destroy
 * @see app/Http/Controllers/ArtikelController.php:50
 * @route '/api/artikel/{artikel}'
 */
destroy.url = (args: { artikel: string | number } | [artikel: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { artikel: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    artikel: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        artikel: args.artikel,
                }

    return destroy.definition.url
            .replace('{artikel}', parsedArgs.artikel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArtikelController::destroy
 * @see app/Http/Controllers/ArtikelController.php:50
 * @route '/api/artikel/{artikel}'
 */
destroy.delete = (args: { artikel: string | number } | [artikel: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ArtikelController::destroy
 * @see app/Http/Controllers/ArtikelController.php:50
 * @route '/api/artikel/{artikel}'
 */
    const destroyForm = (args: { artikel: string | number } | [artikel: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ArtikelController::destroy
 * @see app/Http/Controllers/ArtikelController.php:50
 * @route '/api/artikel/{artikel}'
 */
        destroyForm.delete = (args: { artikel: string | number } | [artikel: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const artikel = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
show: Object.assign(show, show),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default artikel