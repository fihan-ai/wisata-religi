// bootstrap.js placeholder for Breeze
console.log('bootstrap loaded');
