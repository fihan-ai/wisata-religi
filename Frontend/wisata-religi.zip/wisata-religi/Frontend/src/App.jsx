// src/App.jsx
import { Routes, Route, Navigate } from "react-router-dom";
import UserLayout from "./layouts/UserLayout";
import AdminLayout from "./layouts/AdminLayout";
import { use, useEffect } from "react";
import axios from "./api/axios";

// Halaman user
import Home from "./pages/Home";
import Tentang from "./pages/Tentang";
import Galeri from "./pages/Galeri";
import Kontak from "./pages/Kontak";
import BeritaPage from "./pages/BeritaPage";
import Destinasi from "./pages/Destinasi";
import DetailDestinasi from "./pages/DetailDestinasi";
import DetailBerita from "./pages/DetailBerita";

// Halaman admin
import DashboardAdmin from "./pages/admin/DashboardAdmin";
import BeritaAdmin from "./pages/admin/BeritaAdmin";
import DestinasiAdmin from "./pages/admin/DestinasiAdmin";
import BannerAdmin from "./pages/admin/BannerAdmin";

function App() {
  return (
    <Routes>
      {/* --- USER AREA --- */}
      <Route
        path="/"
        element={
          <UserLayout>
            <Home />
          </UserLayout>
        }
      />
      <Route
        path="/tentang"
        element={
          <UserLayout>
            <Tentang />
          </UserLayout>
        }
      />
      <Route
        path="/galeri"
        element={
          <UserLayout>
            <Galeri />
          </UserLayout>
        }
      />
      <Route
        path="/berita"
        element={
          <UserLayout>
            <BeritaPage />
          </UserLayout>
        }
      />
      <Route
        path="/kontak"
        element={
          <UserLayout>
            <Kontak />
          </UserLayout>
        }
      />
      <Route
        path="/destinasi"
        element={
          <UserLayout>
            <Destinasi />
          </UserLayout>
        }
      />
      <Route
        path="/berita/:slug"
        element={
          <UserLayout>
            <DetailBerita />
          </UserLayout>
        }
      />

      <Route
        path="/destinasi/:slug"
        element={
          <UserLayout>
            <DetailDestinasi />
          </UserLayout>
        }
      />

      {/* --- ADMIN AREA --- */}
      <Route
        path="/admin"
        element={
          <AdminLayout>
            <DashboardAdmin />
          </AdminLayout>
        }
      />

      <Route
        path="/admin/berita"
        element={
          <AdminLayout>
            <BeritaAdmin />
          </AdminLayout>
        }
      />

      <Route
        path="/admin/destinasi"
        element={
          <AdminLayout>
            <DestinasiAdmin />
          </AdminLayout>
        }
      />
      <Route
  path="/admin/banner"
  element={
    <AdminLayout>
      <BannerAdmin />
    </AdminLayout>
  }
/>

      {/* Fallbacks */}
      <Route path="/Berita" element={<Navigate to="/berita" replace />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}




export default App;
