  export default [
    {
      id: 1,
      name: "Masjid Jami Pangkalpinang",
      image: "/masjid-jamik-pangkalpinang.jpg",
      description:
        "Salah satu masjid tertua dan pusat kegiatan keagamaan di kota ini.",
    },
    {
      id: 2,
      name: "Klenteng Dewi Laut",
      image: "/klentengdewi.jpg",
      description:
        "Tempat ibadah bersejarah bagi masyarakat Tionghoa di Bangka.",
    },
    {
      id: 3,
      name: "Gereja St. Yosef",
      image: "/gereja.jpg",
      description:
        "Simbol toleransi dan keberagaman umat beragama di Pangkalpinang.",
    },
  ];
