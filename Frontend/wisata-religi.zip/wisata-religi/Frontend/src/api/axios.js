// path: pariwis/src/api/axios.js
import axios from 'axios';

const base = process.env.REACT_APP_API_URL || (window.location.origin + '/api');

const api = axios.create({
  baseURL: base,
  withCredentials: true, // set true kalau nanti pakai session / sanctum
  headers: {
    'Accept': 'application/json',
  },
});

export default api;
